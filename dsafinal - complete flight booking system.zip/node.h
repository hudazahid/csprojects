#ifndef NODE_H
#define NODE_H

#include "itemtype.h"

class Node
{
public:
    Node* parent;
    Node* left;
    Node* right;
    ItemType flight;

    Node();
    Node(ItemType newFlight);
};

#endif
