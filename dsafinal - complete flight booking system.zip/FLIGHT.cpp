//#include <iostream>
//#include <string>
//using namespace std;
//
////surprise features:food menu for each flight
////medical emergency management
////flights grouping by same departure time
//class ItemType
//{
//private:
//	int FlightID;
//	string Destination;
//	string DepartureTime;
//	float Duration;
//	string Status;
//
//	string ActualArrival;  //extra member needed in  labelling flights by comparing with ETA
//	string foodMenu[5];   // stores up to 5 food items per flight
//	float foodPrice[5];   // price for each item
//	int foodCount;
//public:
//	ItemType()
//	{
//		FlightID = 0;
//		Destination = "";
//		DepartureTime = "";
//		Duration = 0;
//		Status = "";
//		ActualArrival = "";
//		foodCount = 0;
//	}
//	ItemType(int Id)      //to initialize object with key only
//	{
//		FlightID = Id;
//		Destination = "";
//		DepartureTime = "";
//		Duration = 0;
//		Status = "";
//		ActualArrival = "";
//		foodCount = 0;
//
//	}
//	ItemType(int Id, string dest, string dep, float dur, string stat, string actualtime)
//	{
//		FlightID = Id;
//		Destination = dest;
//		DepartureTime = dep;
//		Duration = dur;
//		Status = stat;
//		ActualArrival = actualtime;
//		foodCount = 0;
//
//	}
//	void SetId(int Id)
//	{
//		FlightID = Id;
//	}
//	void SetDest(string dest)
//	{
//		Destination = dest;
//	}
//	void SetDep(string dep)
//	{
//		DepartureTime = dep;
//	}
//	void SetDur(float dur)
//	{
//		Duration = dur;
//	}
//	void SetStat(string stat)
//	{
//		Status = stat;
//	}
//	void SetArrival(string actualarrival)
//	{
//		ActualArrival= actualarrival;
//	}
//	void SetVal(int Id, string dest, string dep, float dur, string stat, string actualarrival)
//	{
//		SetId(Id);
//		SetDest(dest);
//		SetDep(dep);
//		SetDur(dur);
//		SetStat(stat);
//		SetArrival(actualarrival);
//		foodCount = 0;
//	}
//	int GetId() const
//	{
//		return FlightID;
//
//	}
//	string GetDest() const
//	{
//		return Destination;
//
//	}
//	string GetDep() const
//	{
//		return DepartureTime;
//
//	}
//	float GetDuration() const
//	{
//		return Duration;
//
//	}
//	string GetStatus() const
//	{
//		return Status;
//
//	}
//	string GetActualArrival() const
//	{
//		return ActualArrival;
//
//	}
//	void GetVal() const
//	{
//		GetId();
//		GetDest();
//		GetDep();
//		GetDuration();
//		GetStatus();
//		GetActualArrival();
//
//	}
//	bool operator<(ItemType& obj) const       //for searching, deletion, insertion(Id is key)
//	{
//		return FlightID < obj.FlightID;
//	}
//	bool operator>(ItemType& obj) const
//	{
//		return FlightID > obj.FlightID;
//	}
//	bool operator==(ItemType& obj) const
//	{
//		return FlightID == obj.FlightID;
//	}
//
//
//	void AddFoodItem(string item, float price)    //adding 5 items per menu
//	{
//		if (foodCount < 5)
//		{
//			foodMenu[foodCount] = item;
//			foodPrice[foodCount] = price;
//			foodCount++;
//		}
//		else
//			cout << "Menu full! Cannot add more items."<<endl;
//	}
//
//	void DisplayMenu()
//	{
//		if (foodCount == 0)
//		{
//			cout << "No food items added for this flight yet."<<endl;
//			return;
//		}
//
//		cout << "Food Menu for Flight " << FlightID <<endl;
//		for (int i = 0; i < foodCount; i++)
//		{
//			cout << "  " << i + 1 << ". " << foodMenu[i]
//				<< " - Rs. " << foodPrice[i] << endl;
//		}
//	}
//
//};
//
//class Node
//{
//public:
//	Node* parent;
//	Node* left;
//	Node* right;
//	ItemType flight;
//	Node()
//	{
//		parent =NULL;
//		left = NULL;
//		right = NULL;
//
//	}
//	Node(ItemType newFlight)  //creating new node
//	{
//		parent = NULL;
//		left = NULL;
//		right = NULL;
//		flight=newFlight ;
//
//	}
//	
//};
//
//class BST
//{
//private:
//	Node* root;
//	int TotalFlights = 0;   //total no of nodes inserted
//	Node* TreeMin(Node*x)
//	{
//		while (x->left != NULL)
//		{
//			x = x->left;
//		}
//		return x;
//	}
//	void Transplant(Node* u, Node* v)
//	{
//		if (u->parent == NULL)
//		{
//			root = v;
//		}
//		else if (u == u->parent->left)
//		{
//			u->parent->left = v;
//		}
//		else
//		{
//			u->parent->right = v;
//		}
//		if (v != NULL)
//		{
//			v->parent = u->parent;
//		}
//
//	}
//	void Inorder(Node* x)
//	{
//		
//		
//			if (x != NULL)
//			{
//				Inorder(x->left);
//				cout << endl;
//				cout << "Flight ID: " << x->flight.GetId() << endl;
//				cout << "Destination: " << x->flight.GetDest() << endl;
//				cout << "Departure Time: " << x->flight.GetDep() << endl;
//				cout << "Duration(in hours): " << x->flight.GetDuration() << " hours" << endl;
//				cout << "Status: " << x->flight.GetStatus() << endl;
//				Inorder(x->right);
//			}
//		
//
//	}
//
//
//	// Collect all unique destinations in one array
//	void CollectDestinations(Node* x, string destinations[], int& count)
//	{
//		if (x == NULL)
//			return;
//
//		
//		CollectDestinations(x->left, destinations, count); //recursive call for left subtree
//
//		// Check if this destination already exists
//		bool ispresent = false;
//		for (int i = 0; i < count; i++)
//		{
//			if (destinations[i] == x->flight.GetDest())
//			{
//				ispresent = true;
//				break;
//			}
//		}
//
//		// If not found, add it
//		if (!ispresent && count < TotalFlights)
//		{
//			destinations[count] = x->flight.GetDest();
//			count++;
//		}
//
//		// Traverse right
//		CollectDestinations(x->right, destinations, count);
//	}  
//
//	// Display all flights belonging to a specific destination
//	void DisplayFlightsByDestination(Node* x, string destination)
//	{
//		if (x == NULL)
//			return;
//
//		DisplayFlightsByDestination(x->left, destination);
//
//		if (x->flight.GetDest() == destination)
//		{
//			cout << "Flight ID: " << x->flight.GetId() << endl
//				<<  "Departure: " << x->flight.GetDep() << endl
//				<<  "Duration: " << x->flight.GetDuration() << "hrs" << endl
//				<<  "Status: " << x->flight.GetStatus() << endl;
//		}
//
//		DisplayFlightsByDestination(x->right, destination);
//	}
//
//	void CollectStatuses(Node* x, string statuses[], int& count)
//	{
//		if (x == NULL)
//			return;
//
//		CollectStatuses(x->left, statuses, count);
//
//		bool ispresent = false;
//		for (int i = 0; i < count; i++)
//		{
//			if (statuses[i] == x->flight.GetStatus())
//			{
//				ispresent = true;
//				break;
//			}
//		}
//
//		if (!ispresent && count < TotalFlights)
//		{
//			statuses[count] = x->flight.GetStatus();
//			count++;
//		}
//
//		CollectStatuses(x->right, statuses, count);
//	}
//
//
//	void DisplayFlightsByStatus(Node* x, string status)
//	{
//		if (x == NULL)
//			return;
//
//		DisplayFlightsByStatus(x->left, status);
//
//		if (x->flight.GetStatus() == status)
//		{
//			cout << "Flight ID: " << x->flight.GetId() << endl
//				<<  "Departure: " << x->flight.GetDep() << endl
//				<<  "Duration: " << x->flight.GetDuration() << "hrs" << endl
//				<<  "Destination: " << x->flight.GetDest() << endl;
//		}
//
//		DisplayFlightsByStatus(x->right, status);
//	}
//	
//	
//	void DisplayFlightsBySameDepTime(Node* x, string dep)
//	{
//		if (x == NULL)
//			return;
//
//		DisplayFlightsBySameDepTime(x->left, dep);
//
//		if (x->flight.GetDep() == dep)
//		{
//			cout << "Flight ID: " << x->flight.GetId() << endl
//				<<  "Duration: " << x->flight.GetDuration() <<"hrs" << endl
//				<<  "Destination: " << x->flight.GetDest() << endl
//				<<  "Status: " << x->flight.GetStatus() << endl;
//		}
//
//
//		DisplayFlightsBySameDepTime(x->right, dep);
//	}
//
//	void ConvertTime(string timeStr, int& hours, int& minutes)
//	{
//		string hourStr = "";
//		string minStr = "";
//		bool minPart = false;
//
//		for (int i = 0; i < timeStr.length(); i++)
//		{
//			if (timeStr[i] == ':')
//			{
//				minPart = true;
//				continue;        //dont check if/else for :
//			}
//			if (!minPart)
//				hourStr += timeStr[i];
//			else
//				minStr += timeStr[i];
//		}
//
//		hours = stoi(hourStr);
//		minutes = stoi(minStr);
//	}
//
//	// Add duration to departure time
//	string AddDuration(string depTime, float duration)
//	{
//		int hours, minutes;
//		ConvertTime(depTime, hours, minutes);
//
//		int durHours = (int)duration;   //converts floating into int (floor)
//		int durMins = (int)((duration - durHours) * 60);   //conversion of minute part
//
//		hours += durHours; //departure hour+duration hour
//		minutes += durMins;//departure min+duration min
//
//		if (minutes >= 60)
//		{
//			hours += minutes / 60;
//			minutes = minutes % 60;
//		}
//
//		if (hours >= 24)
//		{
//			hours = hours % 24;  // wrap around if it goes past midnight
//		}
//
//		string ETA = "";
//
//		if (hours < 10)
//		{
//			ETA += "0";   //leading 0 is hours<10
//		}
//		ETA += to_string(hours);  //convert to string, then concatenate
//		ETA += ":";
//
//		if (minutes < 10)
//		{
//			ETA += "0";
//		}
//		ETA += to_string(minutes);
//
//		return ETA;
//	}
//
//public:
//	BST()
//	{
//		root = NULL;
//		TotalFlights = 0;
//	}
//	void Display(Node* x)
//	{
//		Inorder(x);
//	}
//	Node* GetRoot() const
//	{
//		return root;
//	}
//
//	Node* Search(Node* x, ItemType k)
//	{
//		if (x == NULL || x->flight == k)
//		{
//			return x;
//		}
//		if (k < x->flight)
//		{
//			return Search(x->left, k);
//		}
//		else
//		{
//			return Search(x->right, k);
//		}
//	}
//
//	void Insert(Node* z)
//	{
//		if (Search(root, z->flight) != NULL) 
//		{
//			cout << "Flight ID already exists."<<endl;
//			return;
//		}
//		Node* y = NULL;
//		Node* x = root;
//		while (x != NULL)
//		{
//			y = x;
//			if (z->flight < x->flight)
//			{
//				x = x->left;
//			}
//			else
//			{
//				x = x->right;
//			}
//		}
//		z->parent = y;
//		if (y ==NULL)
//		{
//			root = z;
//		}
//		else if (z->flight < y->flight)
//		{
//			y->left = z;
//		}
//		else
//		{
//			y->right = z;
//		}
//		TotalFlights++;    //node inserted
//		cout << "Flight Added Successfully!" << endl;
//	}
//
//	void Delete(Node* x, ItemType k)
//	{
//		Node* y;
//		Node* z = Search(x, k);
//		if (z == NULL)
//		{
//			cout << " Flight not found."<<endl;
//			return;
//		}
//		if (z->left == NULL)
//		{
//			Transplant(z, z->right);
//
//		}
//		else if (z->right == NULL)
//		{
//			Transplant(z, z->left);
//
//		}
//		else
//
//		{
//			y = TreeMin(z->right);
//			if (y->parent != z)
//			{
//				Transplant(y, y->right);
//				y->right = z->right;
//				y->right->parent = y;
//			}
//			Transplant(z, y);
//
//			y->left = z->left;
//			y->left->parent = y;
//
//		}
//		delete z;
//		TotalFlights--;   //decrement count
//		cout << "Flight deleted successfully."<<endl;
//	}
//	void DisplayDestinationGroup(Node* x)
//	{
//		if (x == NULL)
//		{
//			cout << "No flights in the system"<<endl;
//			return;
//		}
//
//		string *destinations= new string[TotalFlights];
//		int count = 0;
//
//		
//		CollectDestinations(x, destinations, count);
//		for (int i = 0; i < count; i++)
//		{
//			cout << endl <<"Destination: " << destinations[i] << endl;
//			cout << "--------------------------------------" << endl;
//			DisplayFlightsByDestination(x, destinations[i]);
//		}
//
//		delete[] destinations;
//	}
//	void DisplayStatusGroups(Node* x)
//	{
//		if (x == NULL)
//		{
//			cout << "No flights in the system."<<endl;
//			return;
//		}
//
//		string *statuses=new string[TotalFlights];
//		int count = 0;
//
//		CollectStatuses(x, statuses, count);
//
//		for (int i = 0; i < count; i++)
//		{
//			cout << endl<<"Status: " << statuses[i] << endl;
//			cout << "--------------------------------------" << endl;
//			DisplayFlightsByStatus(x, statuses[i]);
//		}
//
//		delete[] statuses;
//	}
//	void DisplaySameDepTimeFlights(Node* x,string dep)
//	{
//		if (x == NULL)
//		{
//			cout << "No flights in the system."<<endl;
//			return;
//		}
//
//		cout << "Flights with same departure time" << endl;
//			cout << "--------------------------------------" << endl;
//			DisplayFlightsBySameDepTime(x, dep);
//		
//	}
//	void DisplayETA(Node* x)
//	{
//		int actualmin;
//		int actualhr;
//		int etamin;
//		int etahr;
//		if (x == NULL)
//			return;
//
//		DisplayETA(x->left);
//
//		string ETA = AddDuration(x->flight.GetDep(), x->flight.GetDuration());
//		string actual = x->flight.GetActualArrival();
//		string status = x->flight.GetStatus();
//		if (actual == "")  // if no actual time entered yet
//		{
//		}
//		else
//		{
//			actualhr = stoi(actual.substr(0, 2));
//			actualmin = stoi(actual.substr(3, 2));
//			etahr = stoi(ETA.substr(0, 2));
//			etamin = stoi(ETA.substr(3, 2));
//
//			if (actualhr < etahr || (actualhr == etahr && actualmin < etamin))
//				status = "Early";
//			else if (actualhr == etahr && actualmin == etamin)
//				status = "On-Time";
//			else
//				status = "Delayed";
//			x->flight.SetStat(status);//update status
//		}
//
//		cout << endl<<" Flight ID: " << x->flight.GetId() << endl
//			<< " Destination: " << x->flight.GetDest()<<endl
//			<< " Departure: " << x->flight.GetDep() << endl
//			<< " Duration: " << x->flight.GetDuration() << " hrs" << endl
//			<< " ETA: " << ETA << endl
//			<< " Status: " << status << endl;
//
//		DisplayETA(x->right);
//	}
//
//	void MedicalEmergency(Node* x, ItemType obj)
//	{
//		Node * emergency=Search(x, obj);
//		if (emergency == NULL)
//		{
//			cout << "Flight not found."<<endl;
//			return;
//		}
//
//		cout << "Medical Emergency declared on Flight " << emergency->flight.GetId() << endl;
//		emergency->flight.SetDest("Nearest Airport");
//		emergency->flight.SetStat("Medical Emergency");
//		emergency->flight.SetDur((emergency->flight.GetDuration()) / 2); //set new dusration to half
//	}
//	void ManageFoodMenu(Node* x, ItemType obj)
//	{
//		Node* food = Search(x, obj);
//		if (food == NULL)
//		{
//			cout << "Flight not found."<<endl;
//			return;
//		}
//		
//			int choice;
//			cout << "1.Add Food Item"<<endl<<"2. View Food Menu"<<endl<<"Enter choice : ";
//			cin >> choice;
//			while (cin.fail() || (choice != 1 && choice != 2)) 
//			{
//				cin.clear();
//				cin.ignore(1000, '\n');
//				cout << "Invalid choice. Enter 1 or 2: ";
//				cin >> choice;
//			}
//
//
//
//			if (choice == 1)
//			{
//				string item;
//				float price;
//				cout << "Enter food item name: ";
//				cin.ignore(numeric_limits<streamsize>::max(), '\n');
//				getline(cin, item);
//				cout << "Enter price: ";
//				cin >> price;
//				food->flight.AddFoodItem(item, price);
//			}
//			else if (choice == 2)
//			{
//				food->flight.DisplayMenu();
//			}
//		
//	}
//
//	void SearchFlightbyID(Node*x, ItemType k)
//
//	{
//		Node* s = Search(x, k);
//		if (s == NULL)
//		{
//			cout << " Flight not found."<<endl;
//			return;
//		}
//		else
//		{
//			cout << "Flight ID: " << s->flight.GetId() << endl
//				<< " Destination: " << s->flight.GetDest() << endl
//				<< " Departure: " << s->flight.GetDep() << endl
//				<< " Duration: " << s->flight.GetDuration() << " hrs" << endl
//				<< "Status: " << s->flight.GetStatus() << endl;
//		}
//
//
//	}
//};
//int main()
//{
//BST tree;
//int choice;
//
//while (true)
//{
//	cout << endl;
//	cout << "FLIGHT RESERVATION DIRECTORY"<<endl;
//	cout << "1. Add New Flight" << endl;
//	cout << "2. Delete a Flight" << endl;
//	cout << "3. Display All Flight (Inorder)" << endl;
//	cout << "4. Display Flights Grouped by Destination" << endl;
//	cout << "5. Display Flights Grouped by Status" << endl;
//	cout << "6. Display Flights Grouped by Same Departure Time" << endl;
//	cout << "7. Display Expected Time of Arrival (ETA)" << endl;
//	cout << "8. Declare Medical Emergency" << endl;
//	cout << "9. Manage Food Menu (Add/View)" << endl;
//	cout << "10. Search Flights By ID" << endl;
//	cout << "11. Exit" << endl;
//	cout << "Enter your choice: " << endl;
//	cin >> choice;
//
//	if (choice == 11)
//	{
//		cout << "Exiting program. Goodbye!" << endl;
//		break;
//	}
//
//	switch (choice)
//	{
//	case 1:
//
//	{
//		int id;
//		string dest, dep, stat, actual;
//		float dur;
//
//		// ID Validation
//		cout << "Enter Flight ID (positive integer): "<<endl;
//		while (true)
//		{
//			cin >> id;
//			if (cin.fail() || id <= 0)
//			{
//				cin.clear();
//				cin.ignore(numeric_limits<streamsize>::max(), '\n');
//
//				cout << "Invalid ID. Enter a valid ID: ";
//			}
//			else
//				break;
//		}
//
//		// Destination Validation 
//		cout << "Enter Destination: ";
//		cin.ignore();
//		getline(cin, dest);
//		while (dest.empty())
//		{
//			cout << " Destination cannot be empty. Re-enter: ";
//			getline(cin, dest);
//		}
//
//		// Departure Time Validation (24-hr format) 
//		cout << "Enter Departure Time (HH:MM in 24-hour format): ";
//		while (true)
//		{
//			getline(cin, dep);
//			if (dep.length() != 5 || dep[2] != ':' ||
//				!isdigit(dep[0]) || !isdigit(dep[1]) ||
//				!isdigit(dep[3]) || !isdigit(dep[4]))
//			{
//				cout << "Invalid format. Use HH:MM (e.g., 14:30): ";
//				continue;
//			}
//			int hour = stoi(dep.substr(0, 2));
//			int min = stoi(dep.substr(3, 2));
//			if (hour < 0 || hour > 23 || min < 0 || min > 59)
//			{
//				cout << " Invalid time. Enter valid 24-hour time: ";
//				continue;
//			}
//			break;
//		}
//
//		// Duration Validation 
//		cout << "Enter Duration (in hours, e.g., 2.5): ";
//		while (true)
//		{
//			cin >> dur;
//			if (cin.fail() || dur <= 0 || dur > 72)
//			{
//				cin.clear();
//				cin.ignore(numeric_limits<streamsize>::max(), '\n');
//
//				cout << "Invalid duration. Enter a positive value (0�72): ";
//			}
//			else
//				break;
//		}
//
//		// Status Validation
//		cout << "Enter Flight Status (Departed/Landed/Delayed): ";
//		cin.ignore();
//		getline(cin, stat);
//
//		// convert to lowercase
//		for (int i = 0; i < stat.length(); i++) 
//		{
//			stat[i] = tolower(stat[i]);
//		}
//
//		while (stat != "departed" && stat != "landed" && stat != "delayed")
//		{
//			cout << "Invalid status. Enter one of: Departed, Landed, or Delayed: ";
//			getline(cin, stat);
//			for (int i = 0; i < stat.length(); i++) 
//			{
//				stat[i] = tolower(stat[i]);
//			}
//		}
//
//
//		// Actual Arrival Validation (optional) 
//		cout << "Enter Actual Arrival Time (HH:MM) or leave blank if not arrived yet: ";
//		getline(cin, actual);
//		if (!actual.empty())
//		{
//			while (actual.length() != 5 || actual[2] != ':' ||
//				!isdigit(actual[0]) || !isdigit(actual[1]) ||
//				!isdigit(actual[3]) || !isdigit(actual[4]))
//			{
//				cout << "Invalid format. Use HH:MM (e.g., 18:45): ";
//				getline(cin, actual);
//			}
//		}
//
//		// set itemtype object
//		ItemType newFlight(id, dest, dep, dur, stat, actual);
//		Node* newNode = new Node(newFlight);
//		tree.Insert(newNode);
//		break;
//	
//	}
//
//        case 2:
//		{
//			int id;
//			cout << "Enter Flight ID (positive integer) to delete: ";
//			while (true)
//			{
//				cin >> id;
//				if (cin.fail() || id <= 0)
//				{
//					cin.clear();
//					cin.ignore(numeric_limits<streamsize>::max(), '\n');
//					cout << "Invalid ID. Enter a valid ID: ";
//				}
//				else
//					break;
//			}
//			ItemType temp(id);
//			tree.Delete(tree.GetRoot(), temp);
//
//			break;
//		}
//
//		case 3:
//			cout << " All Flights Display (Inorder Traversal) "<<endl;
//			tree.Display(tree.GetRoot());
//			break;
//
//		case 4:
//			cout << " Flights Grouped by Destination "<<endl;
//			tree.DisplayDestinationGroup(tree.GetRoot());
//			break;
//
//		case 5:
//			cout << "Flights Grouped by Status "<<endl;
//			tree.DisplayStatusGroups(tree.GetRoot());
//			break;
//
//		case 6:
//		{
//
//			string dep;
//			cout << "Enter Departure Time (HH:MM in 24-hour format): ";
//			cin.ignore(numeric_limits<streamsize>::max(), '\n');
//			while (true)
//			{
//				
//				getline(cin, dep);
//				if (dep.length() != 5 || dep[2] != ':' ||
//					!isdigit(dep[0]) || !isdigit(dep[1]) ||
//					!isdigit(dep[3]) || !isdigit(dep[4]))
//				{
//					cout << " Invalid format. Use HH:MM (e.g., 14:30): ";
//					continue;
//				}
//				int hour = stoi(dep.substr(0, 2));
//				int min = stoi(dep.substr(3, 2));
//				if (hour < 0 || hour > 23 || min < 0 || min > 59)
//				{
//					cout << " Invalid time. Enter valid 24-hour time: ";
//					continue;
//				}
//				break;
//			}
//			tree.DisplaySameDepTimeFlights(tree.GetRoot(), dep);
//			break;
//		}
//			
//		case 7:
//		{
//			cout << "Display ETA and Status "<<endl;
//			tree.DisplayETA(tree.GetRoot());
//			break;
//
//		}
//
//		case 8:
//		{
//			int id;
//			cout << "Enter Flight ID to declare medical emergency: ";
//			while (true)
//			{
//				cin >> id;
//				if (cin.fail() || id <= 0)
//				{
//					cin.clear();
//					cin.ignore(numeric_limits<streamsize>::max(), '\n');
//
//					cout << "Invalid ID. Enter a valid ID: ";
//				}
//				else
//					break;
//			}
//			ItemType temp(id);
//			tree.MedicalEmergency(tree.GetRoot(), temp);
//			cout << "Medical emergency handled successfully!" << endl;
//			break;
//		}
//			
//		case 9:
//		{
//			int id;
//			cout << "Enter Flight ID to manage food menu: ";
//			while (true)
//			{
//				cin >> id;
//				if (cin.fail() || id <= 0)
//				{
//					cin.clear();
//					cin.ignore(numeric_limits<streamsize>::max(), '\n');
//
//					cout << "Invalid ID. Enter a valid ID: ";
//				}
//				else
//					break;
//			}
//			ItemType temp(id);
//			tree.ManageFoodMenu(tree.GetRoot(), temp);
//			break;
//		}
//		case 10:
//		{
//			int id;
//			cout << "Enter Flight ID (positive integer): ";
//			while (true)
//			{
//				cin >> id;
//				if (cin.fail() || id <= 0)
//				{
//					cin.clear();
//					cin.ignore(1000, '\n');
//					cout << "Invalid ID. Enter a valid ID: ";
//				}
//				else
//					break;
//			}
//			ItemType temp(id);
//			tree.SearchFlightbyID(tree.GetRoot(), temp);
//
//		
//			break;
//		}
//
//		default:
//			cout << "Invalid choice!Please try again."<<endl;
//		}
//
//	}
//	return 0;
//}
//	