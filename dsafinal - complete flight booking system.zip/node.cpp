#include "Node.h"

Node::Node() 
{
    parent = nullptr;
    left = nullptr;
    right = nullptr;
}

Node::Node(ItemType newFlight) 
{
    parent = nullptr;
    left = nullptr;
    right = nullptr;
    flight = newFlight;
}
