#include "bfs.h"
#include <iomanip>


string toLowerStr(const string& s) 
{
    string r = "";
    for (int i = 0; i < s.length(); i++)
        r += tolower(s[i]);
    return r;
}


Graph::Graph() 
{
    v = 0;
    adj = nullptr;
    clr = nullptr;
    distance = nullptr;
    parent = nullptr;
    airports = nullptr;
    for (int i = 0; i < 1000; ++i)
        idToIndex[i] = -1;
}

Graph::Graph(int size) 
{
    v = size;


    adj = new int* [v];
    for (int i = 0; i < v; i++)
        adj[i] = new int[v];

    clr = new Color[v];
    distance = new int[v];
    parent = new int[v];
    airports = new Airport[v];

    for (int i = 0; i < 1000; i++)
        idToIndex[i] = -1;
}

Graph::~Graph() 
{
    for (int i = 0; i < v; i++)
        delete[] adj[i];
    delete[] adj;
    delete[] clr;
    delete[] distance;
    delete[] parent;
    delete[] airports;
}


void Graph::AddEdge(int u, int w) 
{
    adj[u][w] = 1;
}


void Graph::AllocateArrays(int size)
{
    v = size;
    adj = new int* [v];
    for (int i = 0; i < v; ++i) {
        adj[i] = new int[v];
        for (int j = 0; j < v; ++j) adj[i][j] = 0;
    }

    clr = new Color[v];
    distance = new int[v];
    parent = new int[v];
    airports = new Airport[v];

    for (int i = 0; i < v; ++i) {
        clr[i] = white;
        distance[i] = -1;
        parent[i] = -1;
        // optionally initialize airports[i] fields (safe defaults)
        airports[i].id = -1;
        airports[i].name = "";
        airports[i].city = "";
        airports[i].country = "";
        airports[i].emergency = 0;
    }

    for (int i = 0; i < 1000; ++i) idToIndex[i] = -1;
}
int Graph::noVertices()
{
    return v;
}


void Graph::LoadAirports(const string& airportFile)
{
    ifstream in(airportFile);
    if (!in) { cout << "Cannot open " << airportFile << "\n"; return; }

    string line;
    int count = 0;
    while (getline(in, line)) if (!line.empty()) ++count;
    in.clear(); in.seekg(0);

    AllocateArrays(count);

    int index = 0;
    while (getline(in, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string idStr, name, city, country, emergencyStr;
        getline(ss, idStr, '|'); getline(ss, name, '|'); getline(ss, city, '|');
        getline(ss, country, '|'); getline(ss, emergencyStr, '|');

        if (idStr.empty() || emergencyStr.empty()) {
            cout << "Skipping malformed airport line: " << line << "\n";
            continue;
        }

        int id = stoi(idStr);
        airports[index].id = id;
        airports[index].name = name;
        airports[index].city = city;
        airports[index].country = country;
        airports[index].emergency = stoi(emergencyStr);

        idToIndex[id] = index;

       

        ++index;
    }

    v = index; // adjust size if some lines were skipped
    in.close();
}

void Graph::LoadRoutes(const string& routeFile)
{
    ifstream in(routeFile);
    if (!in) { cout << "Cannot open " << routeFile << "\n"; return; }

    string line;

    while (getline(in, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string srcStr, destStr;
        getline(ss, srcStr, '|'); getline(ss, destStr, '|');

        int srcID = stoi(srcStr);
        int destID = stoi(destStr);

        if (idToIndex[srcID] == -1 || idToIndex[destID] == -1) {
            cout << "Warning: Route ignored (invalid ID): " << srcID << " -> " << destID << "\n";
            continue;
        }

        int u = idToIndex[srcID];
        int w = idToIndex[destID];
        AddEdge(u, w);
       
    }

    in.close();
  
}

void Graph::BuildIDIndexMap()
{
    for (int i = 0; i < v; i++)
    {
        idToIndex[airports[i].id] = i;
    }
}
void Graph::InitializeAdjMatrix()
{
    for (int i = 0; i < v; i++)
    {
        for (int j = 0; j < v; j++)
        {
            adj[i][j] = 0;
        }
    }
}





void Graph::DisplayAirports()
{
    if (v == 0 || airports == nullptr) {
        cout << "No airports loaded.\n";
        return;
    }

    cout << left
        << setw(8) << "ID"
        << setw(18) << "Name"
        << setw(18) << "City"
        << setw(18) << "Country"
        << setw(10) << "Emergency"
        << endl;

    for (int i = 0; i < v; i++)
    {
        cout << left
            << setw(8) << airports[i].id
            << setw(18) << airports[i].name
            << setw(18) << airports[i].city
            << setw(18) << airports[i].country
            << setw(10) << (airports[i].emergency ? "Yes" : "No")
            << endl;
    }
}
string trim(const string& s) {
    int start = s.find_first_not_of(" \t\r\n");
    int end = s.find_last_not_of(" \t\r\n");
    return (start == -1 ? "" : s.substr(start, end - start + 1));
}




int Graph::SearchAirport(const string& n)
{
    string find = toLowerStr(trim(n));

    for (int i = 0; i < v; i++)
    {
        string name = toLowerStr(trim(airports[i].name));

        if (name == find)
            return airports[i].id;
    }

    return -1;
}



void Graph::BFS(int s)
{
    // quick sanity checks
    if (v <= 0 || adj == nullptr || clr == nullptr || distance == nullptr || parent == nullptr) {
        cout << "BFS: Graph not initialized properly (v=" << v << ", adj=" << (adj != nullptr) << ").\n";
        return;
    }

    if (s < 0 || s >= v) {
        cout << "BFS: start index out of range: " << s << " (v=" << v << ")\n";
        return;
    }

    // initialize arrays
    for (int i = 0; i < v; i++) {
        clr[i] = white;
        distance[i] = -1;
        parent[i] = -1;
    }

    clr[s] = grey;
    distance[s] = 0;
    queue<int> q;
    q.push(s);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        
        if (u < 0 || u >= v) continue;

        for (int w = 0; w < v; w++) {
            
            if (adj[u] == nullptr) continue;

            if (adj[u][w] && clr[w] == white) {
                clr[w] = grey;
                distance[w] = distance[u] + 1;
                parent[w] = u;
                q.push(w);
            }
        }
        clr[u] = black;
    }
}




void Graph::PrintBFSTable()
{
    if (v == 0 || airports == nullptr || distance == nullptr) {
        cout << "No BFS data available.\n";
        return;
    }

    cout << left
        << setw(15) << "Airport"
        << setw(12) << "Distance"
        << setw(20) << "Previous Airport"
        << setw(12) << "Emergency"
        << endl;

    for (int i = 0; i < v; i++)
    {
        cout << left << setw(15) << airports[i].name;

        // Distance
        cout << setw(12) << distance[i];

        // Previous airport
        if (parent[i] == -1)
            cout << setw(20) << "-";
        else
            cout << setw(20) << airports[parent[i]].name;

        // Emergency column
        cout << setw(12) << (airports[i].emergency ? "Yes" : "No");

        cout << endl;
    }
}




bool Graph::IsReachable(int dest) //bfs must be run already before calling this
{
    int idx = idToIndex[dest];
    if (idx == -1) 
        return false;
    return distance[idx] != -1;
}


void Graph::GetRoute(int destID, int route[], int& routeLength)
{
    routeLength = 0;
    if (v == 0 || idToIndex[destID] == -1 || parent == nullptr) return;

    int idx = idToIndex[destID];

    if (distance[idx] == -1 && parent[idx] == -1) {
        // BFS probably not run or destination unreachable
        return;
    }

    while (idx != -1)
    {
        route[routeLength++] = idx;
        idx = parent[idx];
        
        if (routeLength > v) break;
    }

    // reverse as before
    for (int i = 0; i < routeLength / 2; i++) {
        int tmp = route[i];
        route[i] = route[routeLength - 1 - i];
        route[routeLength - 1 - i] = tmp;
    }
}



void Graph::PrintRoute(int route[], int routeLength) 
{
    for (int i = 0; i < routeLength; i++) 
    {
        cout << airports[route[i]].name;
        if (i != routeLength - 1) 
            cout << " -> ";
    }
    cout << endl;
}


void Graph::PrintRouteDetailed(int route[], int routeLength) 
{
    bool noEmergencyWarning = false;
    cout << "Route (" << routeLength - 1 << " stops): ";
    for (int i = 0; i < routeLength; i++) 
    {
        int id = route[i];
        cout << airports[id].name << " (" << airports[id].city << ", " << airports[id].country << ")";
        if (airports[id].emergency) cout << "(E)";
        else noEmergencyWarning = true;
        if (i != routeLength - 1) cout << " -> ";
    }
    cout << endl;
    if (noEmergencyWarning)
        cout << "Warning: Some airports on this route do not have emergency services." << endl;
}
