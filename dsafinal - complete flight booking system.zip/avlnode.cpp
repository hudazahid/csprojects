#include "avlnode.h"

AVLNode::AVLNode() 
{
    left = nullptr;
    right = nullptr;
    parent = nullptr;
    height = 1;
}

AVLNode::AVLNode(ItemType newFlight) 
{
    flight = newFlight;
    left = nullptr;
    right = nullptr;
    parent = nullptr;
    height = 1;
}
