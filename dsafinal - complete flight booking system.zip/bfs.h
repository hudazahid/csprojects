#ifndef BFS_H
#define BFS_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include <string>
using namespace std;

enum Color { white, grey, black };

struct Airport 
{
    int id;        
    string name;
    string city;
    string country;
    int emergency;
};

class Graph 
{
private:
    int v;                  // number of airports
    int** adj;              // adjacency matrix
    Color* clr;
    int* distance;
    int* parent;
   
    

public:
    Airport* airports;
    int idToIndex[1000];    // arr for airport id to array index
    Graph();
    Graph(int size);
    ~Graph();
    void AllocateArrays(int size);
    void  BuildIDIndexMap();
    void InitializeAdjMatrix();

    void AddEdge(int u, int w);
    void LoadAirports(const string& filename);
    void LoadRoutes(const string& filename);
    void DisplayAirports();

    int SearchAirport(const string& n);
    int noVertices();
    void BFS(int s);
    void PrintBFSTable();

    bool IsReachable(int dest);
    void GetRoute(int dest, int route[], int& routeLength);
    void PrintRoute(int route[], int routeLength);
    void PrintRouteDetailed(int route[], int routeLength);
};


string toLowerStr(const string& s);

#endif
