#ifndef BST_H
#define BST_H

#include <iostream>
#include <string>
#include "node.h"
using namespace std;

class BST
{
private:
    Node* root;
    int TotalFlights;

    Node* TreeMin(Node* x);
    void Transplant(Node* u, Node* v);
    void Inorder(Node* x);

    void CollectDestinations(Node* x, string destinations[], int& count);
    void DisplayFlightsByDestination(Node* x, string destination);

    void CollectStatuses(Node* x, string statuses[], int& count);
    void DisplayFlightsByStatus(Node* x, string status);

    void DisplayFlightsBySameDepTime(Node* x, string dep);

    void ConvertTime(string timeStr, int& hours, int& minutes);
    string AddDuration(string depTime, float duration);
    void SaveAfterUpdate(Node* x, ofstream& out);

public:
    BST();

    void Display(Node* x);
    Node* GetRoot() const;
    void PrintTreeClear(Node* node, int depth = 0, string childLabel = "Root"); 

    Node* Search(Node* x, ItemType k);
    void Insert(Node* z);
    void Delete(Node* x, ItemType k);

    void DisplayDestinationGroup(Node* x);
    void DisplayStatusGroups(Node* x);

    void DisplaySameDepTimeFlights(Node* x, string dep);
    void DisplayETA(Node* x);

    void MedicalEmergency(Node* x, ItemType obj);
    void ManageFoodMenu(Node* x, ItemType obj);

    void SearchFlightbyID(Node* x, ItemType k);
    void LoadFromFile(const string& flight);   
    void SaveToFile(const string& flight);
    void BookFlight(Node * x,int id);
};

#endif

