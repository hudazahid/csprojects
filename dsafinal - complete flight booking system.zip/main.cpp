﻿#include <iostream>
#include <string>
#include <limits>
#include <iomanip>
#include <chrono>
#include "bst.h"
#include "avl.h"
#include "bfs.h"
#include "itemtype.h"
#include "node.h"
#include "avlnode.h"

using namespace std;

void clearCin() 
{ 
    cin.clear(); 
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
}
int getInt(const string& s, int minVal = INT_MIN, int maxVal = INT_MAX) //to validate int values(by user)
{
    int x; 
    while (true) 
    {
        cout << s; 
        if (cin >> x && x >= minVal && x <= maxVal) 
        { 
            clearCin(); 
            return x; 
        }
        cout << "  >> Invalid integer input. Try again."<<endl; 
        clearCin();
    }
}
float getFloat(const string& s, float minVal = -1e30f, float maxVal = 1e30f) 
{
    float f; 
    while (true) 
    {
        cout << s; 
        if (cin >> f && f >= minVal && f <= maxVal) 
        { 
            clearCin(); 
            return f; 
        }
        cout << "  >> Invalid number. Try again."<<endl; 
        clearCin();
    }
}
string getLineNonEmpty(const string& str) //tovalidate string inputs(must notbe empty)
{
    string s; 
    while (true) 
    { 
        cout << str; 
        getline(cin, s); 
    if (!s.empty()) 
        return s; 
    cout << "  >> Input cannot be empty."<<endl; 
    }
}
bool confirmYesNo(const string& str) 
{
    string s; 
    while (true) 
    {
        cout << str<< " (y/n): "; 
        getline(cin, s); 
        if (s.empty()) 
            continue; 
        char c = tolower(s[0]);
        if (c == 'y') 
            return true; 
        if (c == 'n') 
            return false; 
        cout << " Please enter y or n." << endl;
    }
}
bool isValidTimeHM(const string& t) 
{
    if (t.size() != 5 || t[2] != ':') 
        return false; 
    for (int i = 0;i < 5;i++) 
        if (i != 2 && (t[i] < '0' || t[i]>'9')) 
            return false;
    int hh = stoi(t.substr(0, 2)), mm = stoi(t.substr(3, 2)); 
    return hh >= 0 && hh <= 23 && mm >= 0 && mm <= 59;
}
string promptTime24(const string& str) 
{ 
    string s; 
    while (true) 
    { 
        cout << str; 
        getline(cin, s); 
        if (isValidTimeHM(s)) 
            return s; 
        cout << "  >> Invalid time HH:MM" << endl;
    }

}
string normalizeStatus(const string& in) 
{
    string s = in; 
    for (int i = 0;s[i];i++) 
        s[i] = tolower(s[i]); 
    if (s == "on-time" || s == "ontime" || s == "on time") 
        return "On-time";
    if (s == "delayed") 
        return "Delayed"; 
    if (s == "cancelled" || s == "canceled") 
        return "Cancelled"; 
    if (s == "departed") 
        return "Departed"; 
    if (s == "landed") 
        return "Landed";
    if (!s.empty()) 
        s[0] = toupper(s[0]); 
    return s;
}
void printHeader(const string& h) 
{ 
    cout << "\n------------------------------\n " << h << "\n------------------------------\n"; 
}
void pause() 
{ 
    cout << "Press Enter..."; 
cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
}


void loadAll(BST& bst, AVLTree& avl, Graph& g) 
{
    bst.LoadFromFile("flights.txt"); 
    avl.LoadFromFile("flights.txt");
    g.LoadAirports("airport.txt"); 
    g.LoadRoutes("route.txt");
}
void saveAll(BST& bst, AVLTree& avl) 
{ 
    bst.SaveToFile("flights.txt"); 
avl.SaveToFile("flights.txt"); 
}
void addNewFlight(BST& bst, AVLTree& avl, Graph& g) 
{
    printHeader("Add New Flight");
    cout << "Available Airports: " << endl;
    // 1️⃣ Show all available airports with IDs
    g.DisplayAirports(); // displays ID and Name

    // 2️⃣ Prompt for Source Airport ID
    int srcID;
    while (true) {
        srcID = getInt("Enter Source Airport ID: ");
        bool found = false;
        for (int i = 0; i < g.noVertices(); i++) {
            if (g.airports[i].id == srcID) {
                found = true;
                break;
            }
        }
        if (found) break;
        cout << "  >> Invalid airport ID. Try again.\n";
    }

    // 3️⃣ Prompt for Destination Airport ID
    int destID;
    while (true) {
        destID = getInt("Enter Destination Airport ID: ");
        if (destID == srcID) {
            cout << "  >> Source and destination cannot be the same.\n";
            continue;
        }
        bool found = false;
        for (int i = 0; i < g.noVertices(); i++) {
            if (g.airports[i].id == destID) {
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "  >> Invalid airport ID. Try again.\n";
            continue;
        }
        break;
    }

    // 4️⃣ Auto-generate FlightID (SourceID*100 + DestID)
    int flightID = srcID * 100 + destID;

    // 5️⃣ Check for duplicates in flights.txt
    ifstream fin("flights.txt");
    bool duplicate = false;
    int existingID, existingSrc, existingDest;
    string dep, status, actualArrival;
    float dur;
    int seats;

    while (fin >> existingID >> existingSrc >> existingDest >> dep >> dur >> status >> actualArrival >> seats) {
        if (existingID == flightID || (existingSrc == srcID && existingDest == destID)) {
            duplicate = true;
            break;
        }
    }
    fin.close();

    if (duplicate) {
        cout << "  >> Flight with same ID or (source, destination) pair already exists.\n";
        pause();
        return;
    }

    // 6️⃣ Ask for other details
    string dest = getLineNonEmpty("Destination: ");
    dep = promptTime24("Departure HH:MM: ");
    dur = getFloat("Duration(hours): ", 0.01f, 72.0f);
    status = normalizeStatus(getLineNonEmpty("Status: "));
    actualArrival = "";
    if (confirmYesNo("Enter actual arrival?"))
        actualArrival = promptTime24("Actual Arrival HH:MM: ");
    seats = getInt("Seats: ", 0);

    // 7️⃣ Create ItemType and insert into BST/AVL
    ItemType it;
    it.SetVal(flightID, dest, dep, dur, status, actualArrival, seats);
    bst.Insert(new Node(it));
    avl.InsertFlight(it);

   

    cout << "  Flight successfully added!(both BST & AVL)" << endl;
    pause();
}





void searchFlight(BST& bst, AVLTree& avl) 
{
    printHeader("Search Flight"); 
    int id = getInt("Flight ID: ", 1); 
    ItemType key; 
    key.SetId(id);
    cout << "BST:"<<endl; 
    Node* nf = bst.Search(bst.GetRoot(), key); 
    if (nf!=nullptr)
        nf->flight.GetVal();
    else cout << "Not found" << endl;
    cout << "AVL:"<<endl; 
    AVLNode* af = avl.Search(avl.GetRoot(), key); 
    if (af!=nullptr) 
        af->flight.GetVal(); 
    else cout << "Not found"<<endl; 
    pause();
}
void deleteFlight(BST& bst, AVLTree& avl) 
{
    printHeader("Delete Flight"); 
    int id = getInt("Flight ID: ", 1); 
    ItemType key; key.SetId(id);
    bst.Delete(bst.GetRoot(), key); 
    avl.DeleteFlight(id);
    cout << " Deleted from BST and AVL trees."<<endl; 
    pause();
}
void displayAllFlightsBST(BST& bst) 
{ 
    printHeader("BST Inorder"); 
    if (!bst.GetRoot()) 
    { 
        cout << "No flights."<<endl; 
    pause(); 
    return; 
    } 
    bst.Display(bst.GetRoot()); 
    pause(); 
}
void displayAllFlightsAVL(AVLTree& avl) 
{ 
    printHeader("AVL Inorder + Rotations"); 
avl.Display(); 
cout << "Rotations: " << avl.GetRotationCount() <<endl; 
pause(); 
}
void displayFlightsByDestBST(BST& bst) 
{ 
    printHeader("Flights by Destination (BST)"); 
    bst.DisplayDestinationGroup(bst.GetRoot()); 
    pause(); 
}
void displayFlightsByDestAVL(AVLTree& avl) {
    printHeader("Flights by Destination (AVL)"); 
    avl.DisplayDestinationGroup(avl.GetRoot()); 
    pause(); 
}
void displayFlightsByStatusBST(BST& bst) 
{ 
    printHeader("Flights by Status (BST)"); 
bst.DisplayStatusGroups(bst.GetRoot()); 
pause(); 
}
void displayFlightsByStatusAVL(AVLTree& avl) 
{ 
    printHeader("Flights by Status (AVL)"); 
    avl.DisplayStatusGroups(avl.GetRoot()); 
    pause(); 
}
void displayFlightsSameDepTimeboth(BST& bst, AVLTree& avl)
{ 
    printHeader("Flights Same Departure BST"); 
string dep = promptTime24("Departure HH:MM: "); 
bst.DisplaySameDepTimeFlights(bst.GetRoot(), dep); 
printHeader("Flights Same Departure (AVL)");
avl.DisplaySameDepTimeFlights(avl.GetRoot(), dep);
pause(); 
}

void displayETA_BST(BST& bst) 
{ 
    printHeader("ETA (BST)"); 
    bst.DisplayETA(bst.GetRoot()); 
    pause(); 
}
void displayETA_AVL(AVLTree& avl) 
{ 
    printHeader("ETA (AVL)"); 
    avl.DisplayETA(avl.GetRoot()); 
    pause(); 
}
void handleMedicalEmergency(BST& bst, AVLTree& avl) 
{
    printHeader("Medical Emergency");
    int id = getInt("Flight ID: ", 1); 
    ItemType obj; 
    obj.SetId(id);
    Node* nf = bst.Search(bst.GetRoot(), obj);
    if (nf == nullptr)
    {
        cout << "Cannot Handle Medical Emergency(Flight doesnt exist)" << endl;
        return;
    }
    bst.MedicalEmergency(bst.GetRoot(), obj); 
    avl.MedicalEmergency(avl.GetRoot(), id);
    cout << " Medical emergency handled in both BST and AVL tree"<<endl; 
    pause();
}
void manageFoodMenuboth(BST& bst, AVLTree& avl)
{ 
    printHeader("Food Menu BST"); 
int id = getInt("Flight ID: ", 1); 
ItemType obj; 
obj.SetId(id); 
bst.ManageFoodMenu(bst.GetRoot(), obj); 
printHeader("Food Menu AVL");
avl.ManageFoodMenu(avl.GetRoot(), obj);
pause(); 
}

void bookFlightBoth(BST& bst, AVLTree& avl) 
{ 
    printHeader("Book Flight"); 
int id = getInt("Flight ID: ", 1); 
ItemType key(id);
Node* nf = bst.Search(bst.GetRoot(), key);
if (nf == nullptr)
{
    cout << "Cannot Book Flight(Flight does not exist)." << endl;
    return;
}
bst.BookFlight(bst.GetRoot(), id); 
avl.BookFlight(avl.GetRoot(), id); 
cout << "Booking done in both BST and AVL."<<endl; 
pause();
}

//menu for flights
void flightOperationsMenu(BST& bst, AVLTree& avl, Graph &g) 
{
    while (true) 
    {
        printHeader("Flight Operations (BST + AVL)");
        cout << "1. Add New Flight"<<endl<<
            "2. Search Flight by ID" << endl << 
            "3. Delete Flight" << endl << 
            "4. Display All Flights" << endl<<
            "5. Display BST & AVL tree strcuture"<<endl<<
            "6. Flights by Destination"<<endl<<
            "7. Flights by Status" << endl <<
            "8. Flights Same Departure" << endl <<
            "9. ETA" << endl<<
            "10. Medical Emergency" << endl <<
            "11.Food Menu" << endl <<
            "12.Book Flight" << endl << 
            "13.Back" << endl ;
        int ch = getInt("Choice: ", 1, 13); // updated to 13

        switch (ch)
        {
        case 1:
            addNewFlight(bst, avl, g);
            break;
        case 2:
            searchFlight(bst, avl);
            break;
        case 3:
            deleteFlight(bst, avl);
            break;
        case 4:
            displayAllFlightsAVL(avl);
            displayAllFlightsBST(bst);
            break;
        case 5: 
            cout << "BST Tree Structure:" << endl;
            bst.PrintTreeClear(bst.GetRoot());
            cout << endl << "AVL Tree Structure:" << endl;
            avl.PrintTreeClear(avl.GetRoot());
            cout << "Rotations: " << avl.GetRotationCount() << endl;
            break;
        case 6:
            displayFlightsByDestAVL(avl);
            displayFlightsByDestBST(bst);
            break;
        case 7:
            displayFlightsByStatusAVL(avl);
            displayFlightsByStatusBST(bst);
            break;
        case 8:
            displayFlightsSameDepTimeboth(bst, avl);
            break;
        case 9:
            displayETA_AVL(avl);
            displayETA_BST(bst);
            break;
        case 10:
            handleMedicalEmergency(bst, avl);
            break;
        case 11:
            manageFoodMenuboth(bst, avl);
            break;
        case 12:
            bookFlightBoth(bst, avl);
            break;
        case 13:
            return; // exit menu
        }
    
    }
}


void bfsSubmenu(Graph& g) 
{
    while (true) 
    {
        printHeader("BFS Menu");
        cout << "1.Display All Airports" << endl <<
            "2.Run BFS from Source" << endl <<
            "3.Print BFS Table(after bfs run)" << endl <<
            "4.Check Reachability" << endl <<
            "5.Print Route" << endl <<
            "6.Print Detailed Route" << endl <<
            "7.Back" << endl;
        int ch = getInt("Choice: ", 1, 7);
        switch (ch) 
        {
        case 1:
        {
            g.DisplayAirports();
            pause();
            break;
        }
        case 2:
        {
            cout << "Search airport by";
            cout << " Name:" << endl;

            string input;
           
            getline(cin, input);

            int airportID = g.SearchAirport(input);

            if (airportID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }
            else
            {
                cout << "Airport found! ID = " << airportID << endl;
            }
            
            int sidx = g.idToIndex[airportID];
            g.BFS(sidx);
            cout << "BFS run successfully!" << endl;


            pause();
            break;
        }

        case 3:
        {
            g.PrintBFSTable();
            pause();
            break;
        }
         
        
        case 4:
        {
            cout << "Search airport by Name:" << endl;

            string srcName;
            getline(cin, srcName);

            int srcID = g.SearchAirport(srcName);

            if (srcID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }

            cout << "Airport found! ID = " << srcID << endl;

            // Convert ID → index
            int sidx = g.idToIndex[srcID];
            g.BFS(sidx);

            cout << "BFS done from " << srcName << endl;

            cout << "Enter Destination Airport: ";
            string destName;
            getline(cin, destName);

            int destID = g.SearchAirport(destName);

            if (destID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }

            cout << "Airport found! ID = " << destID << endl;

            cout << "Reachability: " << (g.IsReachable(destID) ? "Reachable" : "Not reachable") << endl;

            pause();
            break;
        }



        case 5:
        {
            cout << "Search airport by Name:" << endl;
            bool ok;
            string srcName;
            getline(cin, srcName);

            int srcID = g.SearchAirport(srcName);

            if (srcID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }

            cout << "Airport found! ID = " << srcID << endl;

            int sidx = g.idToIndex[srcID];
            g.BFS(sidx);   // BFS always from source ID

            cout << "Destination airport: ";
            string destName;
            getline(cin, destName);

            int destID = g.SearchAirport(destName);

            if (destID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }

            cout << "Airport found! ID = " << destID << endl;

            // GetRoute expects ID
            int route[1000], len = 0;
           ok= g.IsReachable(destID);
           
            if (!ok)
               {
                   cout << "Destination Not Reachable from Source! Cannot print Route." << endl;
                   return;
                }
           
            g.GetRoute(destID, route, len);

            g.PrintRoute(route, len);

            pause();
            break;
        }


       
        case 6:
        {
            cout << "Search airport by Name:" << endl;
            bool ok;
            string srcName;
            getline(cin, srcName);

            int srcID = g.SearchAirport(srcName);

            if (srcID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }

            cout << "Airport found! ID = " << srcID << endl;

            int sidx = g.idToIndex[srcID];
            g.BFS(sidx);

            cout << "BFS done from " << srcName << ".\n";

            cout << "Destination airport: ";
            string destName;
            getline(cin, destName);

            int destID = g.SearchAirport(destName);

            if (destID == -1)
            {
                cout << "Airport not found." << endl;
                pause();
                break;
            }

            cout << "Airport found! ID = " << destID << endl;

            int route[1000], len = 0;
            ok = g.IsReachable(destID);

            if (!ok)
            {
                cout << "Destination Not Reachable from Source! Cannot print Route." << endl;
                return;
            }
            g.GetRoute(destID, route, len);

            g.PrintRouteDetailed(route, len);

            pause();
            break;
        }


        case 7: 
            return;
        }
    }
}


void compareSearchTime(BST& bst, AVLTree& avl) 
{
    printHeader("Compare Search Time");
    int id = getInt("Flight ID: ", 1); 
    ItemType key; 
    key.SetId(id);
    auto t1 = chrono::high_resolution_clock::now();//records current start time
    Node* nf = bst.Search(bst.GetRoot(), key);
    auto t2 = chrono::high_resolution_clock::now();//records time after search
    auto bst_ns = chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();//Calculates how long the search took

    auto t3 = chrono::high_resolution_clock::now();//start time for avl
    AVLNode* af = avl.Search(avl.GetRoot(), key);
    auto t4 = chrono::high_resolution_clock::now();//time after search for avl
    auto avl_ns = chrono::duration_cast<chrono::nanoseconds>(t4 - t3).count();
    
    if (!nf)
    {
        cout << "Not Found" << endl;
        return;
    }
    cout << "BST: " << " Time: " << bst_ns << " ns\n";

    cout << "AVL: " << " Time: " << avl_ns << " ns\n";
 
    pause();
}

int main() 
{
    BST bst; AVLTree avl; Graph g;
    loadAll(bst, avl, g);

    while (true) 
    {
        printHeader("Flight Management System");
        cout << "1. Flight Operations (BST + AVL)" << endl <<
            "2. BFS Trip Planner" << endl <<
            "3. Compare Search Time (BST vs AVL)" << endl <<
            "4. Save Data" << endl <<
            "5. Exit" << endl;
        int choice = getInt("Choice: ", 1, 5);
        switch (choice) 
        {
        case 1: 
            flightOperationsMenu(bst, avl,g); 
            break;
        case 2: 
            bfsSubmenu(g); 
            break;
        case 3: 
            compareSearchTime(bst, avl); 
            break;
        case 4:
            saveAll(bst, avl); 
            cout << "Data saved"<<endl; 
            pause(); 
            break;
        case 5: 
            saveAll(bst, avl); 
            cout << "Exiting..." << endl;
            return 0;
        }
    }
}
