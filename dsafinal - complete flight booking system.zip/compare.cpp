// compare_search_time.cpp

#include <iostream>
#include <chrono>
#include <cstdlib>
#include "bst.h"
#include "avl.h"

using namespace std;
using namespace std::chrono;

// Helper function to generate random flight
ItemType GenerateRandomFlight(int id) {
    string dest = "City" + to_string(rand() % 100);
    string dep = "0" + to_string(rand() % 24) + ":00";
    float duration = float((rand() % 10) + 1); // duration 1-10 hrs
    string status = (rand() % 2 == 0) ? "On Time" : "Delayed";
    string actual = "NA";
    return ItemType(id, dest, dep, duration, status, actual);
}

int main() {
    srand(time(nullptr));

    BST bst;
    AVLTree avl;

    const int numFlights = 1000;   // Simulated number of flights
    const int numSearches = 100;   // Number of search tests
    int totalBSTTime = 0;
    int totalAVLTime = 0;

    // Insert flights into both trees
    for (int i = 1; i <= numFlights; i++) {
        ItemType flight = GenerateRandomFlight(i);

        // BST requires Node*
        Node* bstNode = new Node(flight);
        bst.Insert(bstNode);

        // AVL uses ItemType
        avl.InsertFlight(flight);
    }

    cout << "Inserted " << numFlights << " flights into both BST and AVL.\n";

    // Perform multiple random searches
    for (int i = 0; i < numSearches; i++) {
        int searchID = rand() % numFlights + 1;
        ItemType searchFlight(searchID, "", "", 0, "", "");

        // BST search
        auto startBST = high_resolution_clock::now();
        Node* bstResult = bst.Search(bst.GetRoot(), searchFlight);
        auto endBST = high_resolution_clock::now();
        int bstTime = duration_cast<nanoseconds>(endBST - startBST).count();
        totalBSTTime += bstTime;

        // AVL search
        auto startAVL = high_resolution_clock::now();
        AVLNode* avlResult = avl.GetRoot();
        while (avlResult && avlResult->flight.GetId() != searchID) {
            if (searchID < avlResult->flight.GetId())
                avlResult = avlResult->left;
            else
                avlResult = avlResult->right;
        }
        auto endAVL = high_resolution_clock::now();
        int avlTime = duration_cast<nanoseconds>(endAVL - startAVL).count();
        totalAVLTime += avlTime;
    }

    cout << "Average BST search time: " << totalBSTTime / numSearches << " ns\n";
    cout << "Average AVL search time: " << totalAVLTime / numSearches << " ns\n";

    return 0;
}
