#ifndef ITEMTYPE_H
#define ITEMTYPE_H

#include <iostream>
#include <string>
using namespace std;

class ItemType
{
private:
    int FlightID;
    string Destination;
    string DepartureTime;
    float Duration;
    string Status;
    string ActualArrival;
    string foodMenu[5];
    float foodPrice[5];
    int foodCount;
    int seats;

public:
    ItemType();
    ItemType(int Id);
    ItemType(int Id, string dest, string dep, float dur, string stat, string actualtime,int s);

    void SetId(int Id);
    void SetDest(string dest);
    void SetDep(string dep);
    void SetDur(float dur);
    void SetStat(string stat);
    void SetArrival(string actualarrival);
    void SetSeats(int s);
    void SetVal(int Id, string dest, string dep, float dur, string stat, string actualarrival,int s);

    int GetId() const;
    string GetDest() const;
    string GetDep() const;
    float GetDuration() const;
    string GetStatus() const;
    string GetActualArrival() const;
    int GetSeats() const;
    void GetVal() const;

    bool operator<(ItemType& obj) const;
    bool operator>(ItemType& obj) const;
    bool operator==(ItemType& obj) const;

    void AddFoodItem(string item, float price);
    void DisplayMenu() const;
};

#endif
