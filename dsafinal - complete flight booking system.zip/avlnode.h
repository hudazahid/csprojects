#ifndef AVLNODE_H
#define AVLNODE_H

#include "itemtype.h"

class AVLNode 
{
public:
    ItemType flight;
    AVLNode* left;
    AVLNode* right;
    AVLNode* parent;
    int height;

    AVLNode();
    AVLNode(ItemType newFlight);
};

#endif

