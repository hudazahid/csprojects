﻿#include <iostream>
#include <string>
#include <limits>
#include <fstream>
#include <sstream>
#include "bst.h"
#include "node.h"
#include "itemtype.h"

using namespace std;


Node* BST::TreeMin(Node* x)
{
    while (x->left != NULL)
        x = x->left;
    return x;
}

void BST::Transplant(Node* u, Node* v)
{
    if (u->parent == NULL)
        root = v;
    else if (u == u->parent->left)
        u->parent->left = v;
    else
        u->parent->right = v;

    if (v != NULL)
        v->parent = u->parent;
}

void BST::Inorder(Node* x)
{
    if (x != NULL)
    {
        Inorder(x->left);
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl;
        cout << "Destination: " << x->flight.GetDest() << endl;
        cout << "Departure Time: " << x->flight.GetDep() << endl;
        cout << "Duration(in hours): " << x->flight.GetDuration() << " hours" << endl;
        cout << "Status: " << x->flight.GetStatus() << endl;
        Inorder(x->right);
    }
}
void BST::PrintTreeClear(Node* node, int depth, string childLabel)
{
    if (node != nullptr)
    {
        // Indentation based on depth
        for (int i = 0; i < depth; i++)
            cout << "    ";

        // Print node with its role
        cout << childLabel << ": " << node->flight.GetId() << endl;

        // Preorder: root → left → right
        PrintTreeClear(node->left, depth + 1, "L");
        PrintTreeClear(node->right, depth + 1, "R");
    }
}



void BST::CollectDestinations(Node* x, string destinations[], int& count)
{
    if (x == NULL)
        return;

    CollectDestinations(x->left, destinations, count);

    bool ispresent = false;
    for (int i = 0; i < count; i++)
    {

        if (destinations[i] == x->flight.GetDest())
        {
        
        ispresent = true;
        }
    }

    if (!ispresent && count < TotalFlights) 
    {
        destinations[count] = x->flight.GetDest();
        count++;
    }

    CollectDestinations(x->right, destinations, count);
}

void BST::DisplayFlightsByDestination(Node* x, string destination)
{
    if (x == NULL) 
        return;

    DisplayFlightsByDestination(x->left, destination);

    if (x->flight.GetDest() == destination)
    {
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl
            << "Departure: " << x->flight.GetDep() << endl
            << "Duration: " << x->flight.GetDuration() << "hrs" << endl
            << "Status: " << x->flight.GetStatus() << endl
            << "Available Seats:" << x->flight.GetSeats() << endl;
    }

    DisplayFlightsByDestination(x->right, destination);
}

void BST::CollectStatuses(Node* x, string statuses[], int& count)
{
    if (x == NULL) 
        return;

    CollectStatuses(x->left, statuses, count);

    bool ispresent = false;
    for (int i = 0; i < count; i++)
    {
        if (statuses[i] == x->flight.GetStatus())
        {
 
        ispresent = true;
        }
    }

    if (!ispresent && count < TotalFlights)
    {
        statuses[count] = x->flight.GetStatus();
        count++;
    }

    CollectStatuses(x->right, statuses, count);
}

void BST::DisplayFlightsByStatus(Node* x, string status)
{
    if (x == NULL) 
        return;

    DisplayFlightsByStatus(x->left, status);

    if (x->flight.GetStatus() == status)
    {
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl
            << "Departure: " << x->flight.GetDep() << endl
            << "Duration: " << x->flight.GetDuration() << "hrs" << endl
            << "Destination: " << x->flight.GetDest() << endl
            << "Available Seats:" << x->flight.GetSeats() << endl;
    }

    DisplayFlightsByStatus(x->right, status);
}

void BST::DisplayFlightsBySameDepTime(Node* x, string dep)
{
    if (x == NULL) 
        return;

    DisplayFlightsBySameDepTime(x->left, dep);

    if (x->flight.GetDep() == dep)
    {
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl
            << "Duration: " << x->flight.GetDuration() << "hrs" << endl
            << "Destination: " << x->flight.GetDest() << endl
            << "Status: " << x->flight.GetStatus() << endl
            << "Available Seats:" << x->flight.GetSeats() << endl;
    }

    DisplayFlightsBySameDepTime(x->right, dep);
}

void BST::ConvertTime(string timeStr, int& hours, int& minutes)
{
    string hourStr = "", minStr = "";
    bool minPart = false;

    for (int i = 0; i < timeStr.length(); i++)
    {
        if (timeStr[i] == ':') 
        { 
            minPart = true; 
            continue; 
        }
        if (!minPart) 
            hourStr += timeStr[i];
        else 
            minStr += timeStr[i];
    }

    hours = stoi(hourStr);
    minutes = stoi(minStr);
}

string BST::AddDuration(string depTime, float duration)
{
    int hours, minutes;
    ConvertTime(depTime, hours, minutes);

    int durHours = (int)duration;
    int durMins = (int)((duration - durHours) * 60);

    hours += durHours;
    minutes += durMins;

    if (minutes >= 60) 
    { 
        hours += minutes / 60; 
        minutes %= 60; 
    }
    if (hours >= 24) 
        hours %= 24;

    string ETA = "";
    if (hours < 10) 
        ETA += "0";
    ETA += to_string(hours);
    ETA += ":";
    if (minutes < 10) 
        ETA += "0";
    ETA += to_string(minutes);

    return ETA;
}

void BST::SaveAfterUpdate(Node* x, ofstream& out) 
{
    if (x == NULL) 
        return;

    SaveAfterUpdate(x->left, out);

    
    out << x->flight.GetId() << '|'
        << x->flight.GetDest() << '|'
        << x->flight.GetDep() << '|'
        << x->flight.GetDuration() << '|'
        << x->flight.GetStatus() << '|'
        << x->flight.GetActualArrival() << '|'
        << x->flight.GetSeats() << endl;

    SaveAfterUpdate(x->right, out);
}


BST::BST() 
{ 
    root = NULL; 
    TotalFlights = 0; 
}

Node* BST::GetRoot() const 
{ return root; }

void BST::Display(Node* x) 
{ Inorder(x); }

Node* BST::Search(Node* x, ItemType k)
{
    if (x == NULL || x->flight == k) 
        return x;
    if (k < x->flight) 
        return Search(x->left, k);
    else 
        return Search(x->right, k);
}

void BST::Insert(Node* z)
{
    if (Search(root, z->flight) != NULL)
    {
        cout << "Flight ID already exists." << endl;
        return;
    }

    Node* y = NULL;
    Node* x = root;
    while (x != NULL)
    {
        y = x;
        if (z->flight < x->flight) 
            x = x->left;
        else 
            x = x->right;
    }

    z->parent = y;
    if (y == NULL) 
        root = z;
    else if (z->flight < y->flight) 
        y->left = z;
    else 
        y->right = z;

    TotalFlights++;
    cout << "Flight Added Successfully!" << endl;
}

void BST::Delete(Node* x, ItemType k)
{
    Node* y;
    Node* z = Search(x, k);
    if (z == NULL) 
    { 
        cout << "Flight not found." << endl;  
        return; 
    }
    if (z->left == NULL) 
        Transplant(z, z->right);
    else if (z->right == NULL) 
        Transplant(z, z->left);
    else
    {
        y = TreeMin(z->right);
        if (y->parent != z)
        {
            Transplant(y, y->right);
            y->right = z->right;
            y->right->parent = y;
        }
        Transplant(z, y);
        y->left = z->left;
        y->left->parent = y;
    }
    delete z;
    TotalFlights--;
    cout << "Flight deleted successfully." << endl;
}

void BST::DisplayDestinationGroup(Node* x)
{
    if (x == NULL) 
    { 
        cout << "No flights in the system" << endl; 
        return; 
    }

    string* destinations = new string[TotalFlights];
    int count = 0;

    CollectDestinations(x, destinations, count);
    for (int i = 0; i < count; i++)
    {
        cout << endl << "Destination: " << destinations[i] << endl;
        cout << "--------------------------------------" << endl;
        DisplayFlightsByDestination(x, destinations[i]);
    }

    delete[] destinations;
}

void BST::DisplayStatusGroups(Node* x)
{
    if (x == NULL) 
    { 
        cout << "No flights in the system." << endl; 
        return; 
    }

    string* statuses = new string[TotalFlights];
    int count = 0;

    CollectStatuses(x, statuses, count);
    for (int i = 0; i < count; i++)
    {
        cout << endl << "Status: " << statuses[i] << endl;
        cout << "--------------------------------------" << endl;
        DisplayFlightsByStatus(x, statuses[i]);
    }

    delete[] statuses;
}

void BST::DisplaySameDepTimeFlights(Node* x, string dep)
{
    if (x == NULL) 
    { 
        cout << "No flights in the system." << endl; 
        return; 
    }

    cout << "Flights with same departure time" << endl;
    cout << "--------------------------------------" << endl;
    DisplayFlightsBySameDepTime(x, dep);
}

void BST::DisplayETA(Node* x)
{
    if (x == NULL) return;

    int actualmin, actualhr, etamin, etahr;

    DisplayETA(x->left);

    string ETA = AddDuration(x->flight.GetDep(), x->flight.GetDuration());
    string actual = x->flight.GetActualArrival();
    string status = x->flight.GetStatus();

    if (actual != "")
    {
        actualhr = stoi(actual.substr(0, 2));
        actualmin = stoi(actual.substr(3, 2));
        etahr = stoi(ETA.substr(0, 2));
        etamin = stoi(ETA.substr(3, 2));

        if (actualhr < etahr || (actualhr == etahr && actualmin < etamin))
            status = "Early";
        else if (actualhr == etahr && actualmin == etamin)
            status = "On-Time";
        else
            status = "Delayed";

        x->flight.SetStat(status);
    }

    cout << endl 
        << " Flight ID: " << x->flight.GetId() << endl
        << " Destination: " << x->flight.GetDest() << endl
        << " Departure: " << x->flight.GetDep() << endl
        << " Duration: " << x->flight.GetDuration() << " hrs" << endl
        << " ETA: " << ETA << endl
        << " Status: " << status << endl
        << "Available Seats:" << x->flight.GetSeats() << endl;

    DisplayETA(x->right);
}

void BST::MedicalEmergency(Node* x, ItemType obj)
{
    Node* emergency = Search(x, obj);
    if (emergency == NULL) 
    { 
        cout << "Flight not found." << endl; 
        return; 
    }

    cout << "Medical Emergency declared on Flight " << emergency->flight.GetId() << endl;
    emergency->flight.SetDest("Nearest Airport");
    emergency->flight.SetStat("Medical Emergency");
    emergency->flight.SetDur(emergency->flight.GetDuration() / 2);
}

void BST::ManageFoodMenu(Node* x, ItemType obj)
{
    Node* food = Search(x, obj);
    if (food == NULL) 
    { 
        cout << "Flight not found." << endl; 
        return; 
    }

    int choice;
    cout << "1.Add Food Item" << endl << "2. View Food Menu" << endl << "Enter choice : ";
    cin >> choice;
    while (cin.fail() || (choice != 1 && choice != 2))
    {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Invalid choice. Enter 1 or 2: ";
        cin >> choice;
    }

    if (choice == 1)
    {
        string item;
        float price;
        cout << "Enter food item name: ";
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        getline(cin, item);
        cout << "Enter price: ";
        cin >> price;
        food->flight.AddFoodItem(item, price);
        cout << "Item Added Successfully!" <<  endl;
    }
    else
        food->flight.DisplayMenu();
}

void BST::SearchFlightbyID(Node* x, ItemType k)
{
    Node* s = Search(x, k);
    if (s == NULL) 
    { 
        cout << "Flight not found." << endl; 
        return; 
    }

    cout << "Flight ID: " << s->flight.GetId() << endl
        << " Destination: " << s->flight.GetDest() << endl
        << " Departure: " << s->flight.GetDep() << endl
        << " Duration: " << s->flight.GetDuration() << " hrs" << endl
        << "Status: " << s->flight.GetStatus() << endl
        << "Available Seats: " << s->flight.GetSeats() << endl;

}
void BST::SaveToFile(const string& flights) 
{
    ofstream out(flights);
    if (!out) 
    {
        cout << "Error opening file for writing!" << endl;
        return;
    }

    SaveAfterUpdate(root, out); // write all nodes
    out.close();
}
void BST::LoadFromFile(const string& flights)
{
    ifstream in(flights);
    if (!in)
    {
        cout << "No existing file found. Starting fresh." << endl;
        return;
    }

    string line;
    while (getline(in, line))
    {
        if (line.empty())
            continue;

        stringstream ss(line);
        string idStr, dest, dep, durStr, status, actual,seat;
        getline(ss, idStr, '|');
        getline(ss, dest, '|');
        getline(ss, dep, '|');
        getline(ss, durStr, '|');
        getline(ss, status, '|');
        getline(ss, actual, '|');
        getline(ss, seat, '|');

        int id = stoi(idStr);
        int s = stoi(seat);
        float dur = stof(durStr);
        

        ItemType flight(id, dest, dep, dur, status, actual,s);
        Node* newNode = new Node(flight);
        Insert(newNode); // insert into BST
    }

    in.close();
}

void BST::BookFlight(Node* x,int id)

{
    ItemType obj;
    obj.SetId(id);
    Node* flightNode = Search(x, obj);

    if (!flightNode)
    {
        cout << "Flight not found!" << endl;
        return;
    }

    if (flightNode->flight.GetSeats() <= 0)
    {
        cout << "Sorry! No seats available on this flight." << endl;
        return;
    }

    int s = flightNode->flight.GetSeats();
  
    flightNode->flight.SetSeats(s - 1);


    cout << "Flight booked successfully!" << endl;
    cout << "Seats remaining: " << flightNode->flight.GetSeats() << endl;
}
