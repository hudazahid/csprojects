#include "ItemType.h"
#include <iostream>
using namespace std;

ItemType::ItemType() 
{
    FlightID = 0;
    Destination = "";
    DepartureTime = "";
    Duration = 0;
    Status = "";
    ActualArrival = "";
    foodCount = 0;
    seats = 0;
}

ItemType::ItemType(int Id) 
{
    FlightID = Id;
    Destination = "";
    DepartureTime = "";
    Duration = 0;
    Status = "";
    ActualArrival = "";
    foodCount = 0;
    seats = 0;
}

ItemType::ItemType(int Id, string dest, string dep, float dur, string stat, string actualtime, int s) 
{
    FlightID = Id;
    Destination = dest;
    DepartureTime = dep;
    Duration = dur;
    Status = stat;
    ActualArrival = actualtime;
    foodCount = 0;
    seats = s;
}

void ItemType::SetId(int Id) 
{ FlightID = Id; }
void ItemType::SetDest(string dest) 
{ Destination = dest; }
void ItemType::SetDep(string dep) 
{ DepartureTime = dep; }
void ItemType::SetDur(float dur) 
{ Duration = dur; }
void ItemType::SetStat(string stat) 
{ Status = stat; }
void ItemType::SetArrival(string actualarrival) 
{ ActualArrival = actualarrival; }
void ItemType::SetSeats(int s)
{
    seats=s;
}

void ItemType::SetVal(int Id, string dest, string dep, float dur, string stat, string actualarrival,int s) 
{
    SetId(Id);
    SetDest(dest);
    SetDep(dep);
    SetDur(dur);
    SetStat(stat);
    SetArrival(actualarrival);
    foodCount = 0;
    SetSeats(s);
}

int ItemType::GetId() const 
{ return FlightID; }
string ItemType::GetDest() const 
{ return Destination; }
string ItemType::GetDep() const 
{ return DepartureTime; }
float ItemType::GetDuration() const 
{ return Duration; }
string ItemType::GetStatus() const 
{ return Status; }
string ItemType::GetActualArrival() const 
{ return ActualArrival; }
int ItemType::GetSeats() const
{
    return seats;
}
void ItemType::GetVal() const 
{
    cout<<"Flight ID:"<<GetId() << endl;
    cout << "Destination:" <<GetDest() << endl;
    cout << "Departure Time(HH:MM):" <<GetDep() << endl;
    cout << "Duration(in hrs):" <<GetDuration() << endl;
    cout << "Flight Status:" <<GetStatus() << endl;
    cout << "Actual Arrival Time(HH:MM):" <<GetActualArrival() << endl;
    cout << "No of Seats:" <<GetSeats() << endl;
}

bool ItemType::operator<(ItemType& obj) const 
{ return FlightID < obj.FlightID; }
bool ItemType::operator>(ItemType& obj) const 
{ return FlightID > obj.FlightID; }
bool ItemType::operator==(ItemType& obj) const 
{ return FlightID == obj.FlightID; }

void ItemType::AddFoodItem(string item, float price) 
{
    if (foodCount < 5) 
    {
        foodMenu[foodCount] = item;
        foodPrice[foodCount] = price;
        foodCount++;
    }
    else
        cout << "Menu full! Cannot add more items." << endl;
}


void ItemType::DisplayMenu() const 
{
    if (foodCount == 0) 
    {
        cout << "No food items added for this flight yet." << endl;
        return;
    }

    cout << "Food Menu for Flight " << FlightID << endl;
    for (int i = 0; i < foodCount; i++) 
    {
        cout << "  " << i + 1 << ". " << foodMenu[i]
            << " - Rs. " << foodPrice[i] << endl;
    }
}
