#ifndef AVL_H
#define AVL_H

#include <iostream>
#include <fstream>
#include "avlnode.h"
using namespace std;

class AVLTree 
{
private:
    AVLNode* root;
    int TotalFlights;
    int rotationCount;

    
    AVLNode* Insert(AVLNode* node, AVLNode* parent, ItemType f);
    AVLNode* Delete(AVLNode* node, int flightID);
    AVLNode* LeftRotate(AVLNode* x);
    AVLNode* RightRotate(AVLNode* y);
    int Height(AVLNode* n);
    int GetBalance(AVLNode* n);
    AVLNode* Min(AVLNode* node);

  
    void Inorder(AVLNode* node);
    void SaveAfterUpdate(AVLNode* node, ofstream& out);

   
    void CollectDestinations(AVLNode* node, string destinations[], int& count);

    void DisplayFlightsByDestination(AVLNode* node, string destination);

    void CollectStatuses(AVLNode* node, string statuses[], int& count);

    void DisplayFlightsByStatus(AVLNode* node, string status);

    void DisplayFlightsBySameDepTime(AVLNode* node, string dep);

    void ConvertTime(string timeStr, int& hours, int& minutes);
    string AddDuration(string depTime, float duration);

   

public:
    AVLTree();
    AVLNode* GetRoot() const;
    AVLNode* Search(AVLNode* node, ItemType k);
    void PrintTreeClear(AVLNode* node, int depth = 0, string childLabel = "Root");
  
    void InsertFlight(ItemType f);
    void SearchFlightbyID(AVLNode* x, ItemType k);
    void DeleteFlight(int flightID);
    void Display();
    void SaveToFile(const string& flight);
    void LoadFromFile(const string& flight);
    int GetRotationCount() 
    { return rotationCount; }
    void BookFlight(AVLNode* x,int id);
    void DisplayDestinationGroup(AVLNode* node);
    void DisplayStatusGroups(AVLNode* node);
    void DisplaySameDepTimeFlights(AVLNode* node, string dep);
    void DisplayETA(AVLNode* node);
    void MedicalEmergency(AVLNode* node, ItemType obj);
    void ManageFoodMenu(AVLNode* node, ItemType obj);
};

#endif
