#include "avl.h"
#include <sstream>


AVLTree::AVLTree() 
{
    root = nullptr;
    TotalFlights = 0;
    rotationCount = 0;
}

AVLNode* AVLTree::GetRoot() const 
{
    return root;
}


int AVLTree::Height(AVLNode* n)
{
    if (n != nullptr)
        return n->height;
    else
        return 0;
}


int AVLTree::GetBalance(AVLNode* n)
{
    if (n != nullptr)
    {
        int leftHeight = Height(n->left);
        int rightHeight = Height(n->right);
        return leftHeight - rightHeight;
    }
    else
    {
        return 0;
    }
}


AVLNode* AVLTree::RightRotate(AVLNode* y) 
{
    AVLNode* x = y->left;
    AVLNode* z = x->right;
    x->right = y;
    y->left = z;

    if (z) 
        z->parent = y;
    x->parent = y->parent;
    y->parent = x;

    y->height = max(Height(y->left), Height(y->right)) + 1;
    x->height = max(Height(x->left), Height(x->right)) + 1;

    rotationCount++;
    return x;
}

AVLNode* AVLTree::LeftRotate(AVLNode* x) 
{
    AVLNode* y = x->right;
    AVLNode* z = y->left;
    y->left = x;
    x->right = z;

    if (z) 
        z->parent = x;
    y->parent = x->parent;
    x->parent = y;

    x->height = max(Height(x->left), Height(x->right)) + 1;
    y->height = max(Height(y->left), Height(y->right)) + 1;

    rotationCount++;
    return y;
}


AVLNode* AVLTree::Insert(AVLNode* node, AVLNode* parent, ItemType f) //helper function for insertion
{
    if (node==nullptr) 
    {
        AVLNode* newNode = new AVLNode(f);
        newNode->parent = parent;
        TotalFlights++;
        return newNode; 
    }

    if (f < node->flight) 
        node->left = Insert(node->left, node, f);  //recursive call to find correct spot
    else if 
        (f > node->flight) node->right = Insert(node->right, node, f);
    else return node; //if node already exists, do nothing

    node->height = 1 + max(Height(node->left), Height(node->right)); 
    int balance = GetBalance(node);

    if (balance > 1 && f < node->left->flight) 
        return RightRotate(node);
    if (balance < -1 && f > node->right->flight) 
        return LeftRotate(node);
    if (balance > 1 && f > node->left->flight) 
    { 
        node->left = LeftRotate(node->left); 
        return RightRotate(node); 
    }
    if (balance < -1 && f < node->right->flight) 
    { 
        node->right = RightRotate(node->right); 
        return LeftRotate(node); 
    }

    return node;
}

void AVLTree::InsertFlight(ItemType f) 
{ root = Insert(root, nullptr, f); }

AVLNode* AVLTree::Min(AVLNode* node) 
{
    AVLNode* current = node;
    while (current->left) 
        current = current->left;
    return current;
}

AVLNode* AVLTree::Delete(AVLNode* node, int flightID) 
{
    if (node==nullptr) 
        return node;

    if (flightID < node->flight.GetId()) 
        node->left = Delete(node->left, flightID);
    else if (flightID > node->flight.GetId()) 
        node->right = Delete(node->right, flightID);
    else 
    {
        if (node->left==NULL || node->right==NULL) 
        {
            AVLNode* temp;
            if (node->left != nullptr) 
            {
                temp = node->left;
            }
            else 
            {
                temp = node->right;
            }

            if (!temp) 
            { temp = node; node = nullptr; }
            else 
            { *node = *temp; }
            delete temp;
            TotalFlights--;
        }
        else 
        {
            AVLNode* temp = Min(node->right);
            node->flight = temp->flight;
            node->right = Delete(node->right, temp->flight.GetId());
        }
    }

    if (!node) return node;

    node->height = 1 + max(Height(node->left), Height(node->right));
    int balance = GetBalance(node);

    if (balance > 1 && GetBalance(node->left) >= 0) 
        return RightRotate(node);
    if (balance > 1 && GetBalance(node->left) < 0) 
    { node->left = LeftRotate(node->left); return RightRotate(node); }
    if (balance < -1 && GetBalance(node->right) <= 0) 
        return LeftRotate(node);
    if (balance < -1 && GetBalance(node->right) > 0) 
    { node->right = RightRotate(node->right); return LeftRotate(node); }

    return node;
}

void AVLTree::DeleteFlight(int flightID) 
{ root = Delete(root, flightID); }

void AVLTree::Inorder(AVLNode* node) 
{
    if (node==nullptr) 
        return;
    Inorder(node->left);
    {
        
        cout << endl;
        cout << "Flight ID: " << node->flight.GetId() << endl;
        cout << "Destination: " << node->flight.GetDest() << endl;
        cout << "Departure Time: " << node->flight.GetDep() << endl;
        cout << "Duration(in hours): " << node->flight.GetDuration() << " hours" << endl;
        cout << "Available Seats:" << node->flight.GetSeats() << endl;
        cout << "Status: " << node->flight.GetStatus() << endl;
       
    }
    
    Inorder(node->right);
}
void AVLTree::PrintTreeClear(AVLNode* node, int depth, string childLabel)
{
    if (node != nullptr)
    {
        for (int i = 0; i < depth; i++)
            cout << "    ";
        cout << childLabel << ": " << node->flight.GetId() << endl;

        PrintTreeClear(node->left, depth + 1, "L");
        PrintTreeClear(node->right, depth + 1, "R");
    }
}

void AVLTree::Display() 
{ Inorder(root); }

void AVLTree::SaveAfterUpdate(AVLNode* node, ofstream& out) 
{
    if (node==nullptr) 
        return;
    SaveAfterUpdate(node->left, out);
    out << node->flight.GetId() << '|'
        << node->flight.GetDest() << '|'
        << node->flight.GetDep() << '|'
        << node->flight.GetDuration() << '|'
        << node->flight.GetStatus() << '|'
        << node->flight.GetActualArrival() << '|'
        << node->flight.GetSeats() << endl;
    SaveAfterUpdate(node->right, out);
}

void AVLTree::SaveToFile(const string& flights) 
{
    ofstream out(flights);
    if (!out) return;
    SaveAfterUpdate(root, out);
    out.close();
}

void AVLTree::LoadFromFile(const string& flights) 
{
    ifstream in(flights);
    if (!in) 
        return;
    string line;
    while (getline(in, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string idStr, dest, dep, durStr, status, actual,seat;
        getline(ss, idStr, '|');
        getline(ss, dest, '|');
        getline(ss, dep, '|');
        getline(ss, durStr, '|');
        getline(ss, status, '|');
        getline(ss, actual, '|');
        getline(ss, seat, '|');
        int id = stoi(idStr);
        int s = stoi(seat);
        float dur = stof(durStr);
       
        ItemType flight(id, dest, dep, dur, status, actual,s);
        InsertFlight(flight);
    }
    in.close();
}


AVLNode* AVLTree::Search(AVLNode* node, ItemType k) 
{
    if (!node || node->flight == k) 
        return node;
    if (k < node->flight) return 
        Search(node->left, k);
    return Search(node->right, k);
}

void AVLTree::CollectDestinations(AVLNode* node, string destinations[], int& count) 
{
    if (node==nullptr) 
        return;
    CollectDestinations(node->left, destinations, count);

    bool ispresent = false;
    for (int i = 0; i < count; i++)
    {

        if (destinations[i] == node->flight.GetDest())
        {

            ispresent = true;
        }
    }

    if (!ispresent && count < TotalFlights)
    {
        destinations[count] = node->flight.GetDest();
        count++;
    }


}

void AVLTree::DisplayFlightsByDestination(AVLNode* x, string destination)
{
    if (x == NULL)
        return;

    DisplayFlightsByDestination(x->left, destination);

    if (x->flight.GetDest() == destination)
    {
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl
            << "Departure: " << x->flight.GetDep() << endl
            << "Duration: " << x->flight.GetDuration() << "hrs" << endl
            << "Status: " << x->flight.GetStatus() << endl
            << "Available Seats:" << x->flight.GetSeats() << endl;
            
    }

    DisplayFlightsByDestination(x->right, destination);
}


void AVLTree::CollectStatuses(AVLNode* x, string statuses[], int& count) 
{
    if (x == NULL)
        return;

    CollectStatuses(x->left, statuses, count);

    bool ispresent = false;
    for (int i = 0; i < count; i++)
    {
        if (statuses[i] == x->flight.GetStatus())
        {

            ispresent = true;
        }
    }

    if (!ispresent && count < TotalFlights)
    {
        statuses[count] = x->flight.GetStatus();
        count++;
    }

    CollectStatuses(x->right, statuses, count);
}


void AVLTree::DisplayFlightsByStatus(AVLNode* x, string status) 
{
    if (x == NULL)
        return;

    DisplayFlightsByStatus(x->left, status);

    if (x->flight.GetStatus() == status)
    {
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl
            << "Departure: " << x->flight.GetDep() << endl
            << "Duration: " << x->flight.GetDuration() << "hrs" << endl
            << "Destination: " << x->flight.GetDest() << endl
            << "Available Seats:" << x->flight.GetSeats() << endl;
    }

    DisplayFlightsByStatus(x->right, status);
}



void AVLTree::DisplayFlightsBySameDepTime(AVLNode* x, string dep)
{
    if (x == NULL)
        return;

    DisplayFlightsBySameDepTime(x->left, dep);

    if (x->flight.GetDep() == dep)
    {
        cout << endl;
        cout << "Flight ID: " << x->flight.GetId() << endl
            << "Duration: " << x->flight.GetDuration() << "hrs" << endl
            << "Destination: " << x->flight.GetDest() << endl
            << "Status: " << x->flight.GetStatus() << endl
            << "Available Seats:" << x->flight.GetSeats() << endl;
    }

    DisplayFlightsBySameDepTime(x->right, dep);
}
    
    

void AVLTree::ConvertTime(string timeStr, int& hours, int& minutes) 
{
    {
        string hourStr = "", minStr = "";
        bool minPart = false;

        for (int i = 0; i < timeStr.length(); i++)
        {
            if (timeStr[i] == ':')
            {
                minPart = true;
                continue;
            }
            if (!minPart)
                hourStr += timeStr[i];
            else
                minStr += timeStr[i];
        }

        hours = stoi(hourStr);
        minutes = stoi(minStr);
    }
}

string AVLTree::AddDuration(string depTime, float duration) 
{
    int hours, minutes;
    ConvertTime(depTime, hours, minutes);

    int durHours = (int)duration;
    int durMins = (int)((duration - durHours) * 60);

    hours += durHours;
    minutes += durMins;

    if (minutes >= 60)
    {
        hours += minutes / 60;
        minutes %= 60;
    }
    if (hours >= 24)
        hours %= 24;

    string ETA = "";
    if (hours < 10)
        ETA += "0";
    ETA += to_string(hours);
    ETA += ":";
    if (minutes < 10)
        ETA += "0";
    ETA += to_string(minutes);

    return ETA;
}

void AVLTree::DisplayDestinationGroup(AVLNode* x) 
{
    if (x == NULL)
    {
        cout << "No flights in the system" << endl;
        return;
    }

    string* destinations = new string[TotalFlights];
    int count = 0;

    CollectDestinations(x, destinations, count);
    for (int i = 0; i < count; i++)
    {
        cout << endl << "Destination: " << destinations[i] << endl;
        cout << "--------------------------------------" << endl;
        DisplayFlightsByDestination(x, destinations[i]);
    }

    delete[] destinations;
}

void AVLTree::DisplayStatusGroups(AVLNode* x) 
{
    if (x == NULL)
    {
        cout << "No flights in the system." << endl;
        return;
    }

    string* statuses = new string[TotalFlights];
    int count = 0;

    CollectStatuses(x, statuses, count);
    for (int i = 0; i < count; i++)
    {
        cout << endl << "Status: " << statuses[i] << endl;
        cout << "--------------------------------------" << endl;
        DisplayFlightsByStatus(x, statuses[i]);
    }

    delete[] statuses;
}

void AVLTree::DisplaySameDepTimeFlights(AVLNode* x, string dep) 
{
    if (x == NULL)
    {
        cout << "No flights in the system." << endl;
        return;
    }

    cout << "Flights with same departure time" << endl;
    cout << "--------------------------------------" << endl;
    DisplayFlightsBySameDepTime(x, dep);
}


void AVLTree::DisplayETA(AVLNode* x) 
{
    if (x == NULL) return;

    int actualmin, actualhr, etamin, etahr;

    DisplayETA(x->left);

    string ETA = AddDuration(x->flight.GetDep(), x->flight.GetDuration());
    string actual = x->flight.GetActualArrival();
    string status = x->flight.GetStatus();

    if (actual != "")
    {
        actualhr = stoi(actual.substr(0, 2));
        actualmin = stoi(actual.substr(3, 2));
        etahr = stoi(ETA.substr(0, 2));
        etamin = stoi(ETA.substr(3, 2));

        if (actualhr < etahr || (actualhr == etahr && actualmin < etamin))
            status = "Early";
        else if (actualhr == etahr && actualmin == etamin)
            status = "On-Time";
        else
            status = "Delayed";

        x->flight.SetStat(status);
    }

    cout << endl
        << " Flight ID: " << x->flight.GetId() << endl
        << " Destination: " << x->flight.GetDest() << endl
        << " Departure: " << x->flight.GetDep() << endl
        << " Duration: " << x->flight.GetDuration() << " hrs" << endl
        << " ETA: " << ETA << endl
        << " Status: " << status << endl
        << "Available Seats:" << x->flight.GetSeats() << endl;

    DisplayETA(x->right);
}


void AVLTree::MedicalEmergency(AVLNode* x, ItemType obj)
{
    AVLNode* emergency = Search(x, obj);
    if (emergency == NULL)
    {
        cout << "Flight not found." << endl;
        return;
    }

    cout << "Medical Emergency declared on Flight " << emergency->flight.GetId() << endl;
    emergency->flight.SetDest("Nearest Airport");
    emergency->flight.SetStat("Medical Emergency");
    emergency->flight.SetDur(emergency->flight.GetDuration() / 2);
}


void AVLTree::ManageFoodMenu(AVLNode* x, ItemType obj) 
{
    AVLNode* food = Search(x, obj);
    if (food == NULL)
    {
        cout << "Flight not found." << endl;
        return;
    }

    int choice;
    cout << "1.Add Food Item" << endl << "2. View Food Menu" << endl << "Enter choice : ";
    cin >> choice;
    while (cin.fail() || (choice != 1 && choice != 2))
    {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Invalid choice. Enter 1 or 2: ";
        cin >> choice;
    }

    if (choice == 1)
    {
        string item;
        float price;
        cout << "Enter food item name: ";
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        getline(cin, item);
        cout << "Enter price: ";
        cin >> price;
        food->flight.AddFoodItem(item, price);
        cout << "Item Added Successfully!" << endl;
    }
    else
        food->flight.DisplayMenu();
}
void AVLTree::SearchFlightbyID(AVLNode* x, ItemType k)
{
    AVLNode* s = Search(x, k);
    if (s == NULL)
    {
        cout << "Flight not found." << endl;
        return;
    }

    cout << "Flight ID: " << s->flight.GetId() << endl
        << " Destination: " << s->flight.GetDest() << endl
        << " Departure: " << s->flight.GetDep() << endl
        << " Duration: " << s->flight.GetDuration() << " hrs" << endl
        << "Status: " << s->flight.GetStatus() << endl
        << "Available Seats: " << s->flight.GetSeats() << endl;

}
void AVLTree::BookFlight(AVLNode* x,int id)


{

    ItemType obj(id);
    AVLNode* flightNode = Search(x,obj);  

    if (flightNode==nullptr)
    {
        cout << "Flight not found!" << endl;
        return;
    }

    if (flightNode->flight.GetSeats() <= 0)
    {
        cout << "Sorry! No seats available on this flight." << endl;
        return;
    }
    int s = flightNode->flight.GetSeats();
    flightNode->flight.SetSeats(s-1);
   

    cout << "Flight booked successfully!" << endl;
    cout << "Seats remaining: " << flightNode->flight.GetSeats() << endl;
}
